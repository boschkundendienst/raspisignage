<?php
namespace AIOWPS\Firewall;

/**
 * Use this when throwing an exception if you want to also exit the request
 */
class Exit_Exception extends \Exception {
}
