<?php
/**
 * All of our package actions to register.
 *
 * @package ForceRefresh
 */

namespace JordanLeven\Plugins\ForceRefresh;

require_once __DIR__ . '/admin/actions-admin.php';
require_once __DIR__ . '/client/actions-client.php';
