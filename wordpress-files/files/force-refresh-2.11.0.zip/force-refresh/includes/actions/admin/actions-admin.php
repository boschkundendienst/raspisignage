<?php
/**
 * All of our actions for administrators of our site.
 *
 * @package ForceRefresh
 */

namespace JordanLeven\Plugins\ForceRefresh;

require __DIR__ . '/inc-refresh-ui.php';
require __DIR__ . '/inc-refresh-ui-settings.php';
require __DIR__ . '/inc-refresh-ui-meta-box.php';
require __DIR__ . '/inc-refresh-ui-admin-bar.php';
require __DIR__ . '/inc-release-notes.php';
require __DIR__ . '/inc-roles.php';
