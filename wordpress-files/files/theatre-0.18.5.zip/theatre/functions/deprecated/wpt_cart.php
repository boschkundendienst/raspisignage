<?php

/**
 * @deprecated 0.18.2.
 */
class WPT_Cart {
	
	/**
	 * Leave here because it is being called from the Ticketmatic 3 for WordPress plugin.
	 */
	function reset() {
		
	}
	
}
